export class Students {
    id?: any ;
    name?: string ;
    age?: number ;
    classroom?: string ;
    address?: string ;
    
}
