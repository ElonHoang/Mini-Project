import { Students } from './students.model';

describe('Students', () => {
  it('should create an instance', () => {
    expect(new Students()).toBeTruthy();
  });
});
